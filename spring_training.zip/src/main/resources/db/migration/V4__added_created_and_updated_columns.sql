alter table tasks add column created_on datetime null;
alter table tasks add column updated_on datetime null;